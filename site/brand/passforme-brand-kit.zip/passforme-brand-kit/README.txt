passforme brand kit (https://passforme.com/brand.html)

Colours
  Gold    #e0ac5c   the mark; accents on dark backgrounds
  Brass   #8a5a12   the darker mark; links and accents on light backgrounds
  Ink     #1d2427   text on light
  Night   #13181b   dark background
  Paper   #f3f4f1   light background
  Sheet   #fbfbf9   cards on light; the brass mark's keyhole
  Fog     #e4e7e3   text on dark

Fonts (SIL Open Font License)
  Bricolage Grotesque  titles and the wordmark (weight 750, optical size 96)
  Source Sans 3        text
  JetBrains Mono       code

logo/      the logo, the mark and the wordmark, for light and dark backgrounds
favicon/   favicon.ico, apple-touch-icon, 192 and 512 px icons, per colourway
fonts/     the three fonts as the site serves them (variable woff2) and their licences
social/    avatar and banners (Open Graph, GitHub, X, LinkedIn, YouTube)
